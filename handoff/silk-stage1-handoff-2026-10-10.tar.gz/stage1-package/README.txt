Silk stage1 continuation archive — 2026-10-10

Active committed repair: 3ce3505d6e265ec0380e0e7f6b678b75f2c37d33.
Production validation is pending. PR #1402 remains HOLD for three current N0 depth crashes.

Read HANDOFF.txt first. Original /workspace paths describe the prior cloud environment;
those paths are NOT shared automatically with a new session.

The archive contains:
- stage1-commits.bundle: exact active and fifteen historical source/probe checkpoint commits,
  plus the committed handoff/evidence/tools branch.
- The bundled handoff commit stores byte-verified copies of handoff, helpers, fixtures and receipts.
- HANDOFF.txt: updated continuation instructions and current gate status.

Restore Git history into a normal, non-shallow clone of https://github.com/silk-lang/silk:
  git clone https://github.com/silk-lang/silk.git silk
  git -C silk fetch origin main selfhost native-authenticated-field-reflection
  git -C silk bundle verify /ABSOLUTE/PATH/stage1-package/stage1-commits.bundle
  git -C silk fetch /ABSOLUTE/PATH/stage1-package/stage1-commits.bundle 'refs/heads/*:refs/heads/imported-stage1/*'
  git -C silk switch -c continue-stage1 imported-stage1/native-static-call-frames

The bundle has public repository prerequisites, so use the full clone above.
Historical branches are preserved diagnostics; do not merge their probes into the active repair.
The active candidate is an exact local private commit. Publish a proper-parent public snapshot
using the handoff workflow after the production build; do not blindly push private history.

Restore the supporting files from the bundled handoff commit after importing it:
  mkdir -p /ABSOLUTE/RESTORE
  git -C silk archive imported-stage1/checkpoint/stage1-20261010-handoff stage1-checkpoint | tar -x -C /ABSOLUTE/RESTORE

The restored stage1-checkpoint/workspace/ preserves original paths relative to /workspace. Restore needed files
into /workspace on a new machine, or adapt the helper scripts' explicit paths.
Compiled binaries, LLVM toolchain, dependencies and large LLVM IR are not included. Restore
current N0/N1 from the recorded GitHub Actions artifact IDs; rebuild environment dependencies.
Do not relabel prior generation receipts as evidence for the new candidate.
