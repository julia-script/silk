import hashlib, json, pathlib, sys
root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '/workspace')
manifest = json.loads((root / 'stage1-ownership-supplement-manifest.json').read_text())
for entry in manifest['files']:
    p = root / entry['path']
    assert p.is_file() and not p.is_symlink(), str(p)
    assert p.stat().st_size == entry['bytes'], str(p)
    assert hashlib.sha256(p.read_bytes()).hexdigest() == entry['sha256'], str(p)
    assert p.stat().st_mode & 0o777 == entry['mode'], str(p)
print('All ' + str(len(manifest['files'])) + ' original files verified, including modes.')
