import json
import hashlib
import os
import pathlib
import subprocess
import sys

seed = pathlib.Path(sys.argv[1]).resolve()
fixtures = pathlib.Path(__file__).parent / 'borrow-controls'
output_dir = pathlib.Path(os.environ.get('BORROW_CONTROL_OUTPUT', str(fixtures)))
output_dir.mkdir(parents=True, exist_ok=True)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
print(json.dumps({'event': 'runtime-control-inputs', 'generation': os.environ.get('BORROW_CONTROL_GENERATION', 'unspecified; identify by compilerSha256'), 'compiler': str(seed / 'N0'), 'compilerSha256': sha(seed / 'N0'), 'sources': {path.name: sha(path) for path in sorted(fixtures.glob('*.silk'))}}), flush=True)
selected = set(sys.argv[2:])
cases = [('sum', 42), ('inferred', 42), ('reflect-wrapper', 42), ('positions', 42), ('anonymous', 42), ('private-wrapper', 42), ('foreign-filter', 22), ('stored-reference', 42), ('owned', 'TypeMismatch'), ('mutable', 'TypeMismatch'), ('wrong-owner', 'TypeMismatch'), ('wrong-owner-inferred', 'TypeMismatch'), ('wrong-value', 'TypeMismatch'), ('escape', 'TypeMismatch'), ('wrapper-mutable', 'TypeMismatch'), ('wrapper-owned', 'TypeMismatch'), ('stored-reference-escape', 'TypeMismatch'), ('concrete-label-alias', 42), ('reflected-borrow-wrapper', 42), ('ordinary-static-first', 42), ('ordinary-stored-reference', 42), ('ordinary-inferred-wrong-owner', 'TypeMismatch'), ('ordinary-forwarded-static-first', 42), ('ordinary-static-char', 42), ('ordinary-static-text', 42), ('ordinary-relay-escape', 'TypeMismatch'), ('embedded-text', 42), ('embedded-char', 42), ('embedded-text-array', 42), ('embedded-char-array', 42), ('embedded-nominal', 'Gap.TypedForm'), ('embedded-nominal-array', 'StaticViolation')]
env = dict(os.environ, SILKC_CLANG='/workspace/silk/.scratch/llvm-22.1.8/bin/clang', SILKC_CLANGXX='/workspace/silk/.scratch/llvm-22.1.8/bin/clang++')
failures = 0
for name, expected in cases:
    if selected and name not in selected:
        continue
    evidence = {'case': name, 'sourceSha256': sha(fixtures / (name + '.silk'))}
    try:
        output = output_dir / (name + '.out')
        built = subprocess.run([str(seed / 'N0'), 'build', name + '.silk', '-o', str(output), '--stdlib', str(seed / 'packages/compiler/stdlib'), '--optimization', 'speed', '--debug', 'false'], cwd=fixtures, capture_output=True, text=True, env=env, timeout=120)
        stdout_path = output_dir / (name + '.build.stdout')
        stderr_path = output_dir / (name + '.build.stderr')
        stdout_path.write_text(built.stdout)
        stderr_path.write_text(built.stderr)
        evidence = {'case': name, 'sourceSha256': sha(fixtures / (name + '.silk')), 'buildExit': built.returncode, 'buildStdoutSha256': sha(stdout_path), 'buildStderrSha256': sha(stderr_path)}
        records = [json.loads(line.removeprefix('SILK_BUILD_ERROR=')) for line in built.stderr.splitlines() if line.startswith('SILK_BUILD_ERROR=')]
        if isinstance(expected, str):
            source = (fixtures / (name + '.silk')).read_text()
            call_start = source.index('ownerFirst(owner, field)', source.index('fn wrongInferredOwner')) if name == 'ordinary-inferred-wrong-owner' else source.index('relay(owner, field)', source.index('fn escaping')) if name == 'ordinary-relay-escape' else source.index('packet()', source.index('pub fn main')) if name == 'embedded-nominal' else source.index('[Packet {value: 42}]') if name == 'embedded-nominal-array' else source.index('Intrinsic.borrowField' if 'Intrinsic.borrowField' in source else 'Reflect.borrowField')
            call_end = call_start + len('[Packet {value: 42}]') if name == 'embedded-nominal-array' else source.index(')', call_start) + 1
            if source[call_end:call_end + 2] == '.*':
                call_end += 2
            if expected == 'Gap.TypedForm':
                gaps = [gap for line in built.stderr.splitlines() if line.startswith('SILK_UNSUPPORTED_JSON=') for gap in json.loads(line.removeprefix('SILK_UNSUPPORTED_JSON='))['gaps']]
                matching_gaps = [gap for gap in gaps if gap['code'] == 'typed-form' and gap['source']['module'] == name + '.silk' and gap['source']['span'] == {'start': call_start, 'end': call_end}]
                assert built.returncode == 2 and matching_gaps, (name, built.returncode, built.stderr)
                print(json.dumps(dict(evidence, status='pass', gaps=gaps)), flush=True)
                continue
            matching = [record for record in records if record['code'] == expected and record['module'] == name + '.silk'
                        and record['span']['start'] < call_end and record['span']['end'] > call_start]
            if name == 'embedded-nominal-array':
                matching = [record for record in matching if record['span'] == {'start': call_start, 'end': call_end}]
            assert built.returncode == 1 and matching, (name, built.returncode, built.stderr)
            print(json.dumps(dict(evidence, status='pass', diagnostics=records)), flush=True)
        else:
            assert built.returncode == 0, (name, built.returncode, built.stderr)
            ran = subprocess.run([str(output)], capture_output=True, text=True, timeout=30)
            (output_dir / (name + '.run.stdout')).write_text(ran.stdout)
            (output_dir / (name + '.run.stderr')).write_text(ran.stderr)
            evidence.update(exit=ran.returncode, stdout=ran.stdout, stderr=ran.stderr, binarySha256=sha(output))
            assert (ran.returncode, ran.stdout, ran.stderr) == (expected, '', ''), (name, ran.returncode, ran.stdout, ran.stderr)
            print(json.dumps(dict(evidence, status='pass', exit=ran.returncode, stdout=ran.stdout, stderr=ran.stderr, binarySha256=sha(output))), flush=True)
    except (AssertionError, subprocess.TimeoutExpired) as error:
        failures += 1
        print(json.dumps(dict(evidence, status='fail', reason=str(error))), flush=True)
sys.exit(1 if failures else 0)
