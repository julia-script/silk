Supplement to Silk stage1 handoff — 2026-10-10.
The original archive omitted these ignored files. These are the original bytes, not recreated fixtures.

Extract into /workspace:
  tar -xzf silk-stage1-ownership-fixtures-2026-10-10.tar.gz -C /workspace
  python3 /workspace/stage1-ownership-supplement-verify.py /workspace

Restores:
  /workspace/native-borrow-field/.scratch/borrow-runtime-check.py
  /workspace/native-borrow-field/.scratch/borrow-controls/ (37 files, including 36 Silk sources)
  /workspace/iteration-effect-probes/ (27 original source/log/binary files)
  /workspace/borrow-final-runtime-input-proof.json

The harness SHA-256 is 85b21856729816652f6e12fcdb4e04e1f21c26cd950483d7e52acc5217d6cf99.
All 36 source hashes match the frozen proof for the 32-case harness.
The four immediate/outside-loan sources match both recorded bb7e N0 and N1 receipts.
The verification script checks every supplied file's bytes, SHA-256 and permissions.

Included old iteration .out binaries, logs and receipts are historical evidence, not new compiler
or test results. Run the unchanged harness against the actual newly verified compiler generation.
Retain explicit regular-file stdlib and LLVM toolchain requirements from the original handoff.
